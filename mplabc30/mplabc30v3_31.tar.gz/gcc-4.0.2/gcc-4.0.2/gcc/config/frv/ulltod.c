double __ulltod (unsigned long long a)
{
  return a;
}
